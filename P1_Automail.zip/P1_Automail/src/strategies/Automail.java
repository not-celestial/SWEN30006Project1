package strategies;

import automail.CautiousRobot;
import automail.IMailDelivery;
import automail.NormalRobot;
import automail.Robot;
import automail.StatIgnorer;
import automail.StatRecorder;
import automail.StatTemplate;

public class Automail {
	      
    public Robot[] robots;
    public IMailPool mailPool;
    public StatTemplate statistics;
    public static boolean cautionEnabled = false;
    public static boolean statisticsEnabled = false;
    
    public Automail(IMailPool mailPool, IMailDelivery delivery, int numRobots) {
    	// Swap between simple provided strategies and your strategies here
    	
    	/** Initialize the MailPool */
    	
    	this.mailPool = mailPool;
    	
    	if (statisticsEnabled) {
    		statistics = new StatRecorder();
    	} else {
    		statistics = new StatIgnorer();
    	}
    	
    	/** Initialize robots */
    	robots = new Robot[numRobots];
    	
    	for (int i = 0; i < numRobots; i++) {
    		if (cautionEnabled) {
    			robots[i] = new CautiousRobot(delivery, mailPool, statistics);
    		} else {
    			robots[i] = new NormalRobot(delivery, mailPool, statistics);
    		}
    		
    	}
    }
    
    public void printResults() {
    	statistics.printResults();
    }
    
}
