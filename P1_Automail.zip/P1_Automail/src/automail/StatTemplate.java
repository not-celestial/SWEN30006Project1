package automail;

public abstract class StatTemplate {
	public StatTemplate() {
		
	}
	
	public abstract void recordNormal(MailItem deliveryItem);
	public abstract void recordFragile(MailItem deliveryItem);
	public abstract void tickTimeUnpacking();
	public abstract void printResults();
}
