package automail;

public class StatRecorder extends StatTemplate {
	private int nNormal = 0;
	private int nFragile = 0;
	private int totalNormalWeight = 0;
	private int totalFragileWeight = 0;
	private int totalTimeWrapping = 0;
	
	public void recordNormal(MailItem deliveryItem) {
		nNormal++;
		totalNormalWeight += deliveryItem.weight;
	}
	public void recordFragile(MailItem deliveryItem) {
		nFragile++;
		totalFragileWeight += deliveryItem.weight;		
	}
	public void tickTimeUnpacking() {
		totalTimeWrapping++;
	}
	public void printResults() {
		System.out.println("Total number of packages delivered normally: " + nNormal);
		System.out.println("Total number of packages delivered carefully: " + nFragile);
		System.out.println("Total weight of packages delivered normally: " + totalNormalWeight);
		System.out.println("Total weight of packages delivered carefully: " + totalFragileWeight);
		System.out.println("Amount of time spent wrapping and unwrapping: " + totalTimeWrapping);
	}
}
