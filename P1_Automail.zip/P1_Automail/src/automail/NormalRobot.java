package automail;

import automail.Robot.RobotState;
import exceptions.ExcessiveDeliveryException;
import strategies.IMailPool;

public class NormalRobot extends Robot{
	
	public NormalRobot(IMailDelivery delivery, IMailPool mailPool, StatTemplate statistics) {
		super(delivery, mailPool, statistics);
	}
	
	/**
     * This is called on every time step
     * @throws ExcessiveDeliveryException if robot delivers more than the capacity of the tube without refilling
     */
    public  void step() throws ExcessiveDeliveryException {    	
    	switch(current_state) {
    		/** This state is triggered when the robot is returning to the mailroom after a delivery */
    		case RETURNING:
    			if (!this.returnHome()) {
    				break;
    			}
    		case WAITING:  			
                this.sendOff();
                break;
    		case DELIVERING:  			
    			this.deliver();
                break;
    	}
    }
}
