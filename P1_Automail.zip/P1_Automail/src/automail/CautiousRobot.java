package automail;

public class CautiousRobot {

}
