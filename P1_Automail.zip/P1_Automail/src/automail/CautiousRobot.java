package automail;

import automail.Robot.RobotState;
import exceptions.BreakingFragileItemException;
import exceptions.ExcessiveDeliveryException;
import exceptions.ItemTooHeavyException;
import strategies.IMailPool;

public class CautiousRobot extends Robot{
	private int wrapCounter = 0;
    private boolean hasPacked = false;
    private boolean justUnpacked = false;
    private MailItem specialArm = null;
    //only the cautious robots need to differentiate between normal arms and the delivery item since 
    //normal robots will always deliver the normal arm item first
    private MailItem normalArms = null;
    
	public CautiousRobot(IMailDelivery delivery, IMailPool mailPool, StatTemplate statistics) {
		super(delivery, mailPool, statistics);
		
	}
	
	public void step() throws ExcessiveDeliveryException {    	
    	switch(current_state) {
    		//Serves as a "wait one turn" in order to unpack 
    		case UNPACKING:   			
    			changeState(RobotState.DELIVERING);
    			stats.tickTimeUnpacking();
    			Building.finishUnpacking(this.getCurrentFloor());
    			
    		//This state is triggered once a fragile item is detected, intended to simulate packing for 2 turns
    		case PACKING:
    			wrapCounter++;
    			if (wrapCounter >= 2) {
    				changeState(RobotState.WAITING);
    				wrapCounter = 0;
    				break;
    			}
    			stats.tickTimeUnpacking();
    			break;
    	
    		/** This state is triggered when the robot is returning to the mailroom after a delivery */
    		case RETURNING:
    			// If the floor under it is not travelable, the robot has to wait. We know that the floor is always
    			// below, since the mail room is always on level 1
    			if (this.getCurrentFloor() == 0 || Building.isFloorTravelable(this.getCurrentFloor() - 1)) {
    				if (!this.returnHome()) {
        				break;
        			}
    			}
    			else {
					break;
    			}
    			    			
    		case WAITING:
    			if(isReadyToGo()){
    				//if arm is full, and not already packed, then pack
                	if (specialArm != null && !hasPacked) {
                		wrapCounter = 0;
                		changeState(RobotState.PACKING);
                		hasPacked = true;
                		break;
                	}
                	hasPacked = false;
                	/* Prioritize the fragile items being delivered first */
                	if (specialArm != null) {
                		
                		deliveryItem = specialArm;
                		specialArm = null;
                	} else {
                		deliveryItem = normalArms;
                		normalArms = null;
                	}
    			}    			
                this.sendOff();
                break;
    		case DELIVERING:
    			if(atDestination()){
    				if (deliveryItem.fragile && !justUnpacked) {
    					
    					//if the floor is empty except for the robot, it can start unpacking
    					if (Building.safeToUnpack(this.getCurrentFloor())) {
    						justUnpacked = true;
                        	
                        	changeState(RobotState.UNPACKING);
    					}
                    	break;
                    }    				
    			}
    			justUnpacked = false;
    			/* if the robot is travelling downwards and the floor one below is unpacking, wait, and vice versa */
    			if ((this.getDestinationFloor() > this.getCurrentFloor() && !Building.isFloorTravelable(this.getCurrentFloor() + 1)) ||
    					(this.getDestinationFloor() < this.getCurrentFloor() && !Building.isFloorTravelable(this.getCurrentFloor() - 1))) {
    				break;
    			}
    			this.deliver();
    			if (this.deliveryItem != null && this.atDestination() && this.deliveryItem.fragile) {
    				//claims it starts unpacking before it actually starts in order to prevent new robots entering
					//the floor in order to avoid 2 robots attempting to unpack at the same time
					Building.startUnpacking(this.getCurrentFloor());
					break;
    			}
    			
    			//ensures that the normal arm item gets delivered before the tube item
    			if (normalArms != null && tube == null) {
    				tube = deliveryItem;
                    deliveryItem = normalArms;
                    normalArms = null;
                    setRoute();
                    changeState(RobotState.DELIVERING);
    			
    			}
    	}
    }
	public void addToSpecial(MailItem mailItem) throws ItemTooHeavyException {
		assert(specialArm == null);
		specialArm = mailItem;
		if (specialArm.weight > INDIVIDUAL_MAX_WEIGHT) throw new ItemTooHeavyException();
	}
	
	public boolean isEmpty() {
		return (super.isEmpty() && this.normalArms == null && this.specialArm == null);
	}
	
	public boolean hasSpace() {
		return (super.isEmpty() || this.normalArms == null || this.specialArm == null);
	}
	
	public void addToHand(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException {
		assert(normalArms == null);
		if(mailItem.fragile) throw new BreakingFragileItemException();
		normalArms = mailItem;
		if (normalArms.weight > INDIVIDUAL_MAX_WEIGHT) throw new ItemTooHeavyException();
	}
	
}
