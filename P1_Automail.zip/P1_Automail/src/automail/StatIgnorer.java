package automail;

public class StatIgnorer extends StatTemplate {
	public void recordNormal(MailItem deliveryItem) {
		
	}
	public void recordFragile(MailItem deliveryItem) {
		
	}
	public void tickTimeUnpacking() {
		
	}
	public void printResults() {
		
	}
}
