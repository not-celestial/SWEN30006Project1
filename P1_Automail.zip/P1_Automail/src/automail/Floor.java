package automail;

public class Floor {
	private int numBots = 0;
	private boolean isFragileUnpacking = false;
	
	public Floor() {
		
	}
	
	/**increases number of bots on a floor*/
	public void incrementNumBots() {
		numBots++;
	}
	/**decrease number of bots on a floor*/
	public void decrementNumBots() {
		numBots--;
	}
	/**determines if a robot is unpacking a fragile*/
	public boolean isUnpacking() {
		return isFragileUnpacking;
	}
	
	public void setUnpacking(boolean isUnpacking) {
		isFragileUnpacking = isUnpacking;
	}
	
	public int getNumBots() {
		return numBots;
	}
}
