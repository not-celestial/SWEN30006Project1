package automail;

public class Building {
	
	public static Floor[] FLOOR_OBJECTS;
	
    /** The number of floors in the building **/
    public static int FLOORS;
    
    /** Represents the ground floor location */
    public static final int LOWEST_FLOOR = 1;
    
    /** Represents the mailroom location */
    public static final int MAILROOM_LOCATION = 1;

    public static void changeFloors(int start, int end) {
    	FLOOR_OBJECTS[start].decrementNumBots();
    	FLOOR_OBJECTS[end].incrementNumBots();
    }
    
    public static boolean isFloorTravelable(int floor) {
    	if (FLOOR_OBJECTS[floor].isUnpacking()) {
    		return false;
    	}
    	return true;
    }
    
    public static void startUnpacking(int floor) {
    	FLOOR_OBJECTS[floor].setUnpacking(true);
    }
    
    public static void finishUnpacking(int floor) {
    	FLOOR_OBJECTS[floor].setUnpacking(false);
    }
    
    public static boolean safeToUnpack(int floor) {
    	if (FLOOR_OBJECTS[floor].getNumBots() < 2) {
    		return true;
    	}
    	return false;
    }
}
