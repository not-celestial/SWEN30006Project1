package automail;

public class Floor {
	private int numBots = 0;
	private boolean isFragileUnpacking = false;
	
	public Floor() {
		
	}
	
	public void incrementNumBots() {
		numBots++;
	}
	
	public void decrementNumBots() {
		numBots--;
	}
	
	public boolean isUnpacking() {
		return isFragileUnpacking;
	}
	
	public void setUnpacking(boolean isUnpacking) {
		isFragileUnpacking = isUnpacking;
	}
	
	public int getNumBots() {
		return numBots;
	}
}
