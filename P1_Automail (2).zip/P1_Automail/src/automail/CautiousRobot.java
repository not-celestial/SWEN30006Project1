package automail;

import automail.Robot.RobotState;
import exceptions.ExcessiveDeliveryException;
import exceptions.ItemTooHeavyException;
import strategies.IMailPool;

public class CautiousRobot extends Robot{
	private int wrapCounter = 0;
    private boolean hasPacked = false;
    private boolean justUnpacked = false;
    private MailItem specialArm = null;
    
	public CautiousRobot(IMailDelivery delivery, IMailPool mailPool) {
		super(delivery, mailPool);
		
	}
	
	public void step() throws ExcessiveDeliveryException {    	
    	switch(current_state) {
    		//Serves as a "wait one turn" in order to unpack 
    		case UNPACKING:
    			changeState(RobotState.DELIVERING);
    		//This state is triggered once a fragile item is detected, intended to simulate packing for 2 turns
    		case PACKING:
    			wrapCounter++;
    			if (wrapCounter >= 2) {
    				changeState(RobotState.WAITING);
    				wrapCounter = 0;
    			}
    			break;
    	
    		/** This state is triggered when the robot is returning to the mailroom after a delivery */
    		case RETURNING:
    			if (!this.returnHome()) {
    				break;
    			}
    		case WAITING:
    			if(isReadyToGo()){
    				//if arm is full, and not already packed, then pack
                	if (specialArm != null && !hasPacked) {
                		changeState(RobotState.PACKING);
                		hasPacked = true;
                		break;
                	}
                	hasPacked = false;
                	/* for the edge case that the special arm is filled but no other arm is */
                	if (deliveryItem == null) {
                		deliveryItem = specialArm;
                		specialArm = null;
                	}
    			}    			
                this.sendOff();
                break;
    		case DELIVERING:
    			if(atDestination()){
    				if (deliveryItem.fragile && !justUnpacked) {
                    	justUnpacked = true;
                    	changeState(RobotState.UNPACKING);
                    	break;
                    }    				
    			}
    			justUnpacked = false;
    			if (this.deliver()) {
    				if (specialArm != null) {
                    	deliveryItem = specialArm;
                    	specialArm = null;
                    	setRoute();
                    	changeState(RobotState.DELIVERING);
    				}
    			}
    			
                break;
    	}
    }
	public void addToSpecial(MailItem mailItem) throws ItemTooHeavyException {
		assert(specialArm == null);
		specialArm = mailItem;
		if (specialArm.weight > INDIVIDUAL_MAX_WEIGHT) throw new ItemTooHeavyException();
	}
	
	public boolean isEmpty() {
		return (super.isEmpty() && this.specialArm == null);
	}
	
	public boolean hasSpace() {
		return (super.hasSpace() || this.specialArm == null);
	}
}
