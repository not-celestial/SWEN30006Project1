package automail;

import exceptions.BreakingFragileItemException;
import exceptions.ExcessiveDeliveryException;
import exceptions.ItemTooHeavyException;
import strategies.IMailPool;
import java.util.Map;
import java.util.TreeMap;

/**
 * The robot delivers mail!
 */
public abstract class Robot {
	
    static public final int INDIVIDUAL_MAX_WEIGHT = 2000;

    IMailDelivery delivery;
    protected final String id;
    /** Possible states the robot can be in */
    public enum RobotState {PACKING, DELIVERING, WAITING, RETURNING, UNPACKING }
    public RobotState current_state;
    private int current_floor;
    private int destination_floor;
    private IMailPool mailPool;
    private boolean receivedDispatch;
    
    protected MailItem deliveryItem = null;
    private MailItem tube = null;
    
    
    private int deliveryCounter;
    

    /**
     * Initiates the robot's location at the start to be at the mailroom
     * also set it to be waiting for mail.
     * @param behaviour governs selection of mail items for delivery and behaviour on priority arrivals
     * @param delivery governs the final delivery
     * @param mailPool is the source of mail items
     */
    public Robot(IMailDelivery delivery, IMailPool mailPool){
    	id = "R" + hashCode();
        // current_state = RobotState.WAITING;
    	current_state = RobotState.RETURNING;
        current_floor = Building.MAILROOM_LOCATION;
        this.delivery = delivery;
        this.mailPool = mailPool;
        this.receivedDispatch = false;
        this.deliveryCounter = 0;
    }
    
    public void dispatch() {
    	receivedDispatch = true;
    }
    
    public boolean returnHome() {
    	/** If its current position is at the mailroom, then the robot should change state */
        if(current_floor == Building.MAILROOM_LOCATION){
        	if (tube != null) {
        		mailPool.addToPool(tube);
                System.out.printf("T: %3d >  +addToPool [%s]%n", Clock.Time(), tube.toString());
                tube = null;
        	}
			/** Tell the sorter the robot is ready */
			mailPool.registerWaiting(this);
        	changeState(RobotState.WAITING);
        	return true;
        } else {
        	/** If the robot is not at the mailroom floor yet, then move towards it! */
            moveTowards(Building.MAILROOM_LOCATION);
        	return false;
        }
    }
    
    public void sendOff() {
    	/** If the StorageTube is ready and the Robot is waiting in the mailroom then start the delivery */
        if(!isEmpty() && receivedDispatch){                	                	
        	
        	receivedDispatch = false;
        	deliveryCounter = 0; // reset delivery counter
			setRoute();
        	changeState(RobotState.DELIVERING);
        }
    }
    
    
    public boolean deliver() throws ExcessiveDeliveryException {
    	if(current_floor == destination_floor){ // If already here drop off either way
            /** Delivery complete, report this to the simulator! */                  
            delivery.deliver(deliveryItem);
            deliveryItem = null;
            deliveryCounter++;
            if(deliveryCounter > 3){  // Implies a simulation bug
            	throw new ExcessiveDeliveryException();
            }
            /** Check if want to return, i.e. if there is no item in the tube*/
            if(this.isEmpty()){
            	changeState(RobotState.RETURNING);
            	return false;
            }
            
            else if (tube != null){
                /** If there is another item, set the robot's route to the location to deliver the item */
                deliveryItem = tube;
                tube = null;
                setRoute();
                changeState(RobotState.DELIVERING);
                return false;
            }
            else {
            	return true;
            }
    	} else {
    		/** The robot is not at the destination yet, move towards it! */
    		moveTowards(destination_floor);
    		return false;
    	}
	}

    /**
     * This is called on every time step
     * @throws ExcessiveDeliveryException if robot delivers more than the capacity of the tube without refilling
     */
    public abstract void step() throws ExcessiveDeliveryException;

    /**
     * Sets the route for the robot
     */
    public void setRoute() {
        /** Set the destination floor */
        destination_floor = deliveryItem.getDestFloor();
    }

    /**
     * Generic function that moves the robot towards the destination
     * @param destination the floor towards which the robot is moving
     */
    private void moveTowards(int destination) {
        if(current_floor < destination){
            current_floor++;
        } else {
            current_floor--;
        }
    }
    
    public boolean atDestination() {
    	return (this.current_floor == this.destination_floor);
    }
    
    public boolean isReadyToGo() {
    	return (!isEmpty() && receivedDispatch);
    }
    
    private String getIdTube() {
    	return String.format("%s(%1d)", id, (tube == null ? 0 : 1));
    }
    
    /**
     * Prints out the change in state
     * @param nextState the state to which the robot is transitioning
     */
    protected void changeState(RobotState nextState){
    	assert(!(deliveryItem == null && tube != null));
    	if (current_state != nextState) {
            System.out.printf("T: %3d > %7s changed from %s to %s%n", Clock.Time(), getIdTube(), current_state, nextState);
    	}
    	current_state = nextState;
    	if(nextState == RobotState.DELIVERING){
            System.out.printf("T: %3d > %9s-> [%s]%n", Clock.Time(), getIdTube(), deliveryItem.toString());
    	}
    }

	public MailItem getTube() {
		return tube;
	}
    
	static private int count = 0;
	static private Map<Integer, Integer> hashMap = new TreeMap<Integer, Integer>();

	@Override
	public int hashCode() {
		Integer hash0 = super.hashCode();
		Integer hash = hashMap.get(hash0);
		if (hash == null) { hash = count++; hashMap.put(hash0, hash); }
		return hash;
	}

	public boolean isEmpty() {
		return (deliveryItem == null && tube == null);
	}
	
	public boolean hasSpace() {
		return (deliveryItem == null || tube == null);
	}

	public void addToHand(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException {
		assert(deliveryItem == null);
		if(mailItem.fragile) throw new BreakingFragileItemException();
		deliveryItem = mailItem;
		if (deliveryItem.weight > INDIVIDUAL_MAX_WEIGHT) throw new ItemTooHeavyException();
	}

	public void addToTube(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException {
		assert(tube == null);
		if(mailItem.fragile) throw new BreakingFragileItemException();
		tube = mailItem;
		if (tube.weight > INDIVIDUAL_MAX_WEIGHT) throw new ItemTooHeavyException();
	}
	
	
}
